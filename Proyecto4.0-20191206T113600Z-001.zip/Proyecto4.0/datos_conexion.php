<?php	

$db_host="localhost";
	$db_nombre="citas_medicas";
	$db_usuario="root";
	$db_contra="";

?>